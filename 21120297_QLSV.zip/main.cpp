#include <iostream>
#include "QL_SV.h"
#include "Student.h"
#include "Menu.h"
#define _CRT_SECURE_NO_WARNINGS
#pragma warning(disable:4996)
using namespace std;

int main()
{
	Menu menu;
	menu.display();

	return 0;
}